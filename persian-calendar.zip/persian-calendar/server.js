const express = require('express');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const cors = require('cors');

const app = express();

// Middlewares
app.use(cors());
app.use(helmet());
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use('/js', express.static(path.join(__dirname, 'node_modules', 'jalaali-js', 'dist')));
app.use(express.static('public'));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/day', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'day.html'));
});

// In-memory events
const events = [];

app.get('/api/events', (req, res) => {
    const date = req.query.date;
    res.json(events.filter(e => e.date === date));
});

app.post('/api/events', (req, res) => {
    events.push(req.body);
    res.json({ success: true });
});

app.delete('/api/events', (req, res) => {
    const date = req.query.date;
    const index = events.findIndex(e => e.date === date);
    if (index > -1) {
        events.splice(index, 1);
    }
    res.json({ success: true });
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('خطایی در سرور رخ داده است');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`سرور در حال اجرا است: http://localhost:${PORT}`);
});
