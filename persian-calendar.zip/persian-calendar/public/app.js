document.addEventListener('DOMContentLoaded', () => {
    const path = window.location.pathname;
    if (path.includes('index.html') || path === '/') {
        initCalendar();
    } else if (path.includes('day.html')) {
        loadDayPage();
    }
});

let currentYear, currentMonth;

async function initCalendar() {
    const today = new Date();
    const jDate = jalaali.toJalaali(today);
    currentYear = jDate.jy;
    currentMonth = jDate.jm;
    await renderCalendar(currentYear, currentMonth);
}

async function renderCalendar(year, month) {
    const daysInMonth = jalaali.jalaaliMonthLength(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    const startIndex = (firstDay + 1) % 7;

    let html = '<table class="calendar-table"><tr><th>ش</th><th>ی</th><th>د</th><th>س</th><th>چ</th><th>پ</th><th>ج</th></tr><tr>';

    for (let i = 0; i < startIndex; i++) {
        html += '<td></td>';
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}/${month}/${day}`;
        const hasEvent = await checkForEvent(dateStr);

        if ((day + startIndex - 1) % 7 === 0 && day !== 1) {
            html += '</tr><tr>';
        }

        html += `<td class="day-cell">
                    <a href="day.html?date=${dateStr}" class="day-link ${hasEvent ? 'day-event' : ''}">
                        ${day}
                    </a>
                 </td>`;
    }

    html += '</tr></table>';
    document.getElementById('calendar').innerHTML = html;
    document.getElementById('month-title').textContent = `${jalaali.jalaaliMonthNames[month-1]} ${year}`;
}

function getFirstDayOfMonth(year, month) {
    const gregorian = jalaali.toGregorian(year, month, 1);
    return new Date(gregorian.gy, gregorian.gm - 1, 1).getDay();
}

async function checkForEvent(date) {
    try {
        const response = await fetch(`/api/events?date=${date}`);
        const events = await response.json();
        return events.length > 0;
    } catch (error) {
        console.error('خطا در دریافت رویدادها:', error);
        return false;
    }
}

document.getElementById('prev-month').addEventListener('click', () => {
    if (currentMonth === 1) {
        currentMonth = 12;
        currentYear--;
    } else {
        currentMonth--;
    }
    renderCalendar(currentYear, currentMonth);
});

document.getElementById('next-month').addEventListener('click', () => {
    if (currentMonth === 12) {
        currentMonth = 1;
        currentYear++;
    } else {
        currentMonth++;
    }
    renderCalendar(currentYear, currentMonth);
});

async function loadDayPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const date = urlParams.get('date');
    if (!date) return goBack();
    
    document.getElementById('date-title').textContent = `رویدادهای ${date}`;

    try {
        const response = await fetch(`/api/events?date=${date}`);
        const events = await response.json();
        document.getElementById('event').value = events.map(e => e.eventText).join('\n');
    } catch (error) {
        console.error('خطا در دریافت رویدادها:', error);
    }
}

async function saveEvent() {
    const urlParams = new URLSearchParams(window.location.search);
    const date = urlParams.get('date');
    const eventText = document.getElementById('event').value.trim();

    try {
        const response = await fetch('/api/events', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ date, eventText }),
        });

        alert(response.ok ? 'رویداد ذخیره شد!' : 'خطا در ذخیره‌سازی');
    } catch (error) {
        console.error('خطا:', error);
        alert('خطا در ارتباط با سرور');
    }
}

function goBack() {
    window.location.href = 'index.html';
}
